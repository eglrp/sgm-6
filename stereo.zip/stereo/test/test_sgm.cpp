/**@copyright 2016 Horizon-Robotics Inc. All Rights Reserved.
 * @author Degang Yang (degang.yang@horizon-robotics.com)
 *
 * @file test_sgm.cpp
 * @brief test_sgm.cpp
 */

#include <iostream>
#include <string>

#include <opencv2/opencv.hpp>
#include <opencv/highgui.h>

#include "stereo/include/utility.h"
#include "stereo/include/sgm_stereo.h"
#include "test_utility.h"

int main(int argc, char **argv)
{
	std::string left_img_path(argv[1]);
        std::string right_img_path(argv[2]);
	std::string output_colored_disparitymap = left_img_path.substr(0, left_img_path.size() - 4) + "_disparity.png";
	int levels_disparity = 200;

	unsigned char* img_left = NULL, *img_right = NULL;
	size_t width, height;
	loadImageRGB(left_img_path.c_str(), width, height, img_left);/*loading the gray image as RGB is fine, [gray, gray, gray]*/
	loadImageRGB(right_img_path.c_str(), width, height, img_right);
	int size = width*height, size3 = width*height * 3;
	unsigned char* img_tmp = new unsigned char[size3];
	float* guidance_left = new float[size3];

	std::cout << "Begin to calculate the disparity map..." << std::endl;
	deeprob::cv::SGMStereo matcher((int)width, (int)height, levels_disparity, 3, 3);
	deeprob::cv::BoxFilter(img_left, img_tmp, 1, 1, width, height, 3);/*pre-smoothing on guidance_left*/
	for (int i = 0; i < size3; ++i) guidance_left[i] = img_tmp[i];

	matcher.setImage(img_left, img_right, 3);
	matcher.setGuidance(guidance_left, NULL, 3);
	matcher.calDisparity(); /*calculate the disparity map*/

	std::cout << "Done! Result is saved." << std::endl;
	showDataFalseColor(matcher._disparity[0], width, height, NULL, output_colored_disparitymap.c_str(), true);/*save the disparity map in false color*/

	delete[]img_tmp;
	delete[]guidance_left;
	delete[]img_left;
	delete[]img_right;
	return (1);
}
